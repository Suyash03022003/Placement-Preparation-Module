# Placement-Preparation-Module

### Prerequisites:
1. Install git
2. Install node.js

### Clone the Repository:
Open terminal and navigate to the path where you have to clone this project and run the below command.

git clone https://github.com/Suyash03022003/Placement-Preparation-Module.git

### Open 2 terminals and navigate to the path where you have cloned this repo:
In the first terminal enter: 

cd frontend -> Enter -> npm i --force -> Enter -> npm start -> Enter


In the second terminal enter:

cd backend -> Enter -> npm i -> Enter -> npm run dev -> Enter

### Run the below link in URL:
http://localhost:3000/

1. Register Yourself
2. Log In
