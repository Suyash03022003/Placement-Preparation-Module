export const userData = [
    {
        name: "",
        "Active Time(Hr)": 0,
    },
    {
        name: "Monday",
        "Active Time(Hr)": 4,
    },
    {
        name: "Tuesday",
        "Active Time(Hr)": 3,
    },
    {
        name: "Wednesday",
        "Active Time(Hr)": 5,
    },
    {
        name: "Thrusday",
        "Active Time(Hr)": 4,
    },
    {
        name: "Friday",
        "Active Time(Hr)": 3,
    },
    {
        name: "Saturday",
        "Active Time(Hr)": 2,
    },
    {
        name: "Sunday",
        "Active Time(Hr)": 9,
    },


];