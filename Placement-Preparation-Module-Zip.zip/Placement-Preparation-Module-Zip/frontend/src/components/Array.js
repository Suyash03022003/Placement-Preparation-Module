import React from 'react';

const Array = () => {
    return (
        <div>
            <h1>About page</h1>
        </div>
    );
};

export default Array;