import React from 'react';

const String = () => {
    return (
        <div>
            <h1>About page</h1>
        </div>
    );
};

export default String;