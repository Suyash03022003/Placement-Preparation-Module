export const PORT = 5000;

export const mongodbURL = "mongodb+srv://root:root@placementpreparationmod.xnudoih.mongodb.net/users?retryWrites=true&w=majority";